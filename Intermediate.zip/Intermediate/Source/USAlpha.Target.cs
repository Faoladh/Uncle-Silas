using UnrealBuildTool;

public class USAlphaTarget : TargetRules
{
	public USAlphaTarget(TargetInfo Target) : base(Target)
	{
		Type = TargetType.Game;
		ExtraModuleNames.Add("USAlpha");
	}
}
